// USDC Contract on Arc Testnet
export const USDC_ADDRESS = '0x3600000000000000000000000000000000000000' as const

// ERC-20 ABI for USDC operations
export const ERC20_ABI = [
  {
    name: 'balanceOf',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'account', type: 'address' }],
    outputs: [{ name: '', type: 'uint256' }],
  },
  {
    name: 'transfer',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'to', type: 'address' },
      { name: 'amount', type: 'uint256' },
    ],
    outputs: [{ name: '', type: 'bool' }],
  },
  {
    name: 'approve',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'spender', type: 'address' },
      { name: 'amount', type: 'uint256' },
    ],
    outputs: [{ name: '', type: 'bool' }],
  },
] as const

// Service provider wallet (receives payments)
// In production, this would be the service provider's wallet
export const SERVICE_PROVIDER_ADDRESS = '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb2' as const

// Available AI services with pricing
export interface AIService {
  id: string
  name: string
  description: string
  price: string // in USDC
  endpoint: string
  icon: string
}

export const AI_SERVICES: AIService[] = [
  {
    id: 'gpt4-api',
    name: 'GPT-4 API Access',
    description: 'Advanced language model for complex reasoning tasks',
    price: '0.10',
    endpoint: '/api/ai/gpt4',
    icon: '🤖'
  },
  {
    id: 'image-gen',
    name: 'Image Generation',
    description: 'AI-powered image creation from text prompts',
    price: '0.25',
    endpoint: '/api/ai/image-gen',
    icon: '🎨'
  },
  {
    id: 'data-analysis',
    name: 'Data Analysis',
    description: 'Automated data processing and insights generation',
    price: '0.15',
    endpoint: '/api/ai/data-analysis',
    icon: '📊'
  },
  {
    id: 'code-review',
    name: 'Code Review',
    description: 'AI-assisted code quality analysis and suggestions',
    price: '0.20',
    endpoint: '/api/ai/code-review',
    icon: '💻'
  },
]
