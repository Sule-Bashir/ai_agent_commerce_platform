export type AgentState = 
  | 'idle' 
  | 'requesting' 
  | 'payment-required' 
  | 'approving-payment' 
  | 'processing-payment' 
  | 'verifying' 
  | 'success' 
  | 'error'

export interface AgentActivity {
  id: string
  timestamp: number
  type: 'request' | 'payment' | 'unlock' | 'error'
  message: string
  details?: any
}

export interface AgentConfig {
  name: string
  autoApprove: boolean
  maxPaymentAmount: string
}
